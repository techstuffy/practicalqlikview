These a my own examples creating during the practical qlikview book\video course.
These examples will not be directly referenced in the book\course.

You will need a qlikview license to open these qvw files.
